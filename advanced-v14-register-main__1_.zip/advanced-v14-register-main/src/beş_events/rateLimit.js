module.exports = async function(RateLimitData) {
console.log("⚠️ Beş_Rate_Limit_Warn; ", RateLimitData)}
module.exports.conf = {
name: "rateLimit"
}