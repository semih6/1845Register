module.exports = async function(e){
console.log(`⚠️ Beş_App_Error; `+e)}

module.exports.conf = {
name: "error"
}