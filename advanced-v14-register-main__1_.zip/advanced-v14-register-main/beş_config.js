module.exports = {

token:"", //Bot Tokeniniz => Bot Oluşturduktan Sonra Intentsleri Açmayı Unutma!
guildID:"", //Kullanıcağın Sunucunun ID'si
botDurum:"Beş Was Here", //Botun Durumu
footer:"Beş & Luppux", //Embedların Footer Yazısı
botOwners:["928259219038302258"], //Bot Sahibinin ID'si
prefix:".", //Botun Prefix'i 
manemoji:"♂️", //Erkek Emojisi
womanemoji:"♀️", //Kadın Emojisi
tagSymbol:"5", //Sunucunun Taglı İsim Sembolu => Eğer Tagınız Yoksa Boş Bırakın Veya "5" Kalsın
normalSymbol:"•", //Normal Kayıt Olucak Kullanıcıların Başına Gelicek Sembol
symbolBeş:"|", //Kayıt Esnasında İsim Ve Yaş'ı Ayıran Çizgi
minageAge:15, //En Düşük Kayıt Edilebilir Yaş
welcomeResimURL:"https://cdn.discordapp.com/attachments/950167988127006821/1088263193832472656/beeautiful-sunset-illustration-1212023.png", //Resimli Hoşgeldin Tasarımının Arkaplan'ı => URL Şeklinde Giriniz / gif veya webp Uzantısı Kabul Etmez  
welcomeResimRenk:"#861765", //Resimli Hoşgeldin Tasarımının Çerçeve Rengi => HexColor Şeklinde Giriniz
kayitsizHesapIsim:"İsim | Yaş", //Kayıtsızların Düzeltileceği İsim
supheliHesapIsim:"Şüpheli", //Şüpheli Hesapların Düzeltileceği İsim


//Aşşağıdakiler Hoşgeldinde Gözüken Sayı Emojileridir Kendiniz Doldurmak İsterseniz Doldurursunuz

//Eğer Buraya Kadar Yaptıysan .setup Komudunu Kullanarak Botu Sunucuna Kurmaya Başla.

sayılarEmoji:{
sıfır:"0",
bir:"1",
iki:"2",
üç:"3",
dört:"4",
beş:"5",
altı:"6",
yedi:"7",
sekiz:"8",
dokuz:"9"
}




}